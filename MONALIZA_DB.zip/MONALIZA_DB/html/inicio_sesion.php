<?php
// Iniciar la sesión
session_start();

// Incluir conexión a la base de datos
include 'db.php';

if (isset($_POST['iniciar_sesion'])) {
    $email = $_POST['usuario_email'];
    $contraseña = $_POST['usuario_contraseña'];

    // Validar campos no vacíos
    if (!empty($email) && !empty($contraseña)) {
        // Consultar usuario en la base de datos
        $sql = "SELECT * FROM Usuario WHERE usuario_email = '$email'";
        $resultado = mysqli_query($conexion, $sql);

        if (mysqli_num_rows($resultado) > 0) {
            $usuario = mysqli_fetch_assoc($resultado);

            // Verificar la contraseña
            if (password_verify($contraseña, $usuario['usuario_contraseña'])) {
                // Crear variables de sesión
                $_SESSION['usuario_id'] = $usuario['id']; // ID único del usuario
                $_SESSION['usuario_email'] = $usuario['usuario_email'];
                $_SESSION['usuario_nombre'] = $usuario['usuario_nombres'];

                // Redirigir al área protegida
                header("Location: dashboard.php");
                exit();
            } else {
                echo "<script>alert('Contraseña incorrecta');</script>";
            }
        } else {
            echo "<script>alert('Usuario no encontrado');</script>";
        }
    } else {
        echo "<script>alert('Por favor, completa todos los campos');</script>";
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio de Sesión</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h2>Iniciar Sesión</h2>
        <form method="post" action="inicio_sesion.php">
            <div class="form-group">
                <label for="usuario_email">Correo Electrónico</label>
                <input type="email" name="usuario_email" id="usuario_email" placeholder="ejemplo@correo.com" required>
            </div>
            <div class="form-group">
                <label for="usuario_contraseña">Contraseña</label>
                <input type="password" name="usuario_contraseña" id="usuario_contraseña" placeholder="Escribe tu contraseña" required>
            </div>
            <button type="submit" class="btn" name="iniciar_sesion">Iniciar Sesión</button>
            <a href="registro.php">¿No tienes cuenta? Regístrate</a>
        </form>
    </div>
</body>
</html>
