<?php
require('fpdf.php');

// Iniciar sesión
session_start();

// Verificar si el usuario está logueado
if (!isset($_SESSION['usuario_id'])) {
    die("No estás autorizado para generar el certificado.");
}

// Conexión a la base de datos
$conexion = new mysqli("localhost", "root", "", "tu_base_de_datos");
if ($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Obtener el nombre del usuario desde la base de datos
$usuario_id = $_SESSION['usuario_id'];
$resultado = $conexion->query("SELECT nombre FROM usuarios WHERE id = $usuario_id");

$nombre_usuario = "Estudiante"; // Nombre predeterminado
if ($resultado && $resultado->num_rows > 0) {
    $fila = $resultado->fetch_assoc();
    $nombre_usuario = $fila['nombre'];
}

// Crear el PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Título
$pdf->Cell(0, 10, 'Certificado de Curso Completado', 0, 1, 'C');
$pdf->Ln(10);

// Contenido del certificado
$pdf->SetFont('Arial', '', 12);
$pdf->MultiCell(0, 10, utf8_decode("Felicidades, $nombre_usuario.\n\nHas completado con éxito el curso:\n\nCreación de Páginas Web en HTML.\n\nFecha de emisión: " . date('d/m/Y')), 0, 'C');
$pdf->Ln(20);

// Firma ficticia
$pdf->SetFont('Arial', 'I', 12);
$pdf->Cell(0, 10, 'Firma: _____________________', 0, 1, 'C');

// Salida del PDF
$pdf->Output('D', 'Certificado_Curso_HTML.pdf');
