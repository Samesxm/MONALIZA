<?php
// Incluye la conexión a la base de datos
include 'db.php';

// Procesar registro
if (isset($_POST['registrar'])) {
    $nombres = $_POST['usuario_nombres'];
    $apellido_materno = $_POST['usuario_Apellido_Materno'];
    $apellido_paterno = $_POST['usuario_Apellido_Paterno'];
    $email = $_POST['usuario_email'];
    $contraseña = $_POST['usuario_contraseña'];

    if (!empty($nombres) && !empty($apellido_materno) && !empty($apellido_paterno) && !empty($email) && !empty($contraseña)) {
        $contraseña_cifrada = password_hash($contraseña, PASSWORD_BCRYPT);
        $sql = "INSERT INTO Usuario (usuario_nombres, usuario_Apellido_Materno, usuario_Apellido_Paterno, usuario_email, usuario_contraseña)
                VALUES ('$nombres', '$apellido_materno', '$apellido_paterno', '$email', '$contraseña_cifrada')";
        if (mysqli_query($conexion, $sql)) {
            echo "<script>alert('Registro exitoso');</script>";
        } else {
            echo "<script>alert('Error al registrar');</script>";
        }
    }
}

// Procesar inicio de sesión
if (isset($_POST['iniciar_sesion'])) {
    $email = $_POST['usuario_email'];
    $contraseña = $_POST['usuario_contraseña'];

    if (!empty($email) && !empty($contraseña)) {
        $sql = "SELECT usuario_contraseña FROM Usuario WHERE usuario_email = '$email'";
        $resultado = mysqli_query($conexion, $sql);
        if (mysqli_num_rows($resultado) > 0) {
            $fila = mysqli_fetch_assoc($resultado);
            if (password_verify($contraseña, $fila['usuario_contraseña'])) {
                echo "<script>alert('Inicio de sesión exitoso');</script>";
            } else {
                echo "<script>alert('Contraseña incorrecta');</script>";
            }
        } else {
            echo "<script>alert('El usuario no existe');</script>";
        }
    }
}
?>

<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registro</title>
</head>
<body>
    <div class="container">
        <h2>Registro</h2>
        <form method="post" action="registro.php">
            <div class="form-group">
                <label for="usuario_nombres">Nombres</label>
                <input type="text" name="usuario_nombres" id="usuario_nombres" placeholder="Escribe tus nombres" required>
            </div>
            <div class="form-group">
                <label for="usuario_Apellido_Materno">Apellido Materno</label>
                <input type="text" name="usuario_Apellido_Materno" id="usuario_Apellido_Materno" placeholder="Apellido materno" required>
            </div>
            <div class="form-group">
                <label for="usuario_Apellido_Paterno">Apellido Paterno</label>
                <input type="text" name="usuario_Apellido_Paterno" id="usuario_Apellido_Paterno" placeholder="Apellido paterno" required>
            </div>
            <div class="form-group">
                <label for="usuario_email">Correo Electrónico</label>
                <input type="email" name="usuario_email" id="usuario_email" placeholder="ejemplo@correo.com" required>
            </div>
            <div class="form-group">
                <label for="usuario_contraseña">Contraseña</label>
                <input type="password" name="usuario_contraseña" id="usuario_contraseña" placeholder="Escribe tu contraseña" required>
            </div>
            <button type="submit" class="btn" name="registrar">Registrar</button>
            <a href="inicio_sesion.php">¿Ya tienes cuenta? Inicia sesión</a>
        </form>
    </div>
</body>
</html>

