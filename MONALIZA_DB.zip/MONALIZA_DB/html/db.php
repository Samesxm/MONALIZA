<?php
// Datos de conexión
$servidor = "localhost";
$usuario = "root";
$clave = "";
$bd = "MONALIZA_DB";

// Conexión a la base de datos
$conexion = mysqli_connect($servidor, $usuario, $clave, $bd);

// Verificar conexión
if (!$conexion) {
    die("Error al conectar con la base de datos: " . mysqli_connect_error());
}
?>
